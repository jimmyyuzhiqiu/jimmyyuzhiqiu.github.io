# 安装

解压后让小龙虾先读 `SKILL.md`。

快速调用：
```bash
URL1='...' URL2='...' SHA256='...' OUTPUT='package.zip' EXTRACT_DIR='package' bash bootstrap.sh
```

本 Skill 不绑定具体存储商；默认适配 jsDelivr / GitHub Raw / GitHub Pages，也可放 Cloudflare R2、OSS、COS 的签名 URL。
