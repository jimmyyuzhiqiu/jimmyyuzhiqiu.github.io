# Agent Artifact Fetch Skill V1

## Purpose
For a mainland-China Linux agent/container (“小龙虾”) that needs to receive files produced elsewhere without manual browser upload.

The skill accepts one or more artifact URLs plus an optional SHA256, downloads with fallback routes, verifies bytes, extracts archives, and identifies the execution entrypoint such as `MASTER_PROMPT.md`.

## Preferred routing policy

### Tier A — small public immutable artifacts
Use a public GitHub repository + immutable commit SHA.
Preferred download order:
1. jsDelivr pinned to exact commit SHA
2. GitHub Raw pinned to exact commit SHA
3. GitHub Pages only as an optional fallback

Never use `@main` as the authoritative integrity-checked URL.

### Tier B — larger artifacts
If the single file is beyond jsDelivr’s practical GitHub file limit, skip jsDelivr.
Prefer:
1. Cloudflare R2 when configured
2. GitHub Release / another object store
3. GitHub Raw only if the file is within ordinary GitHub repository limits

### Tier C — private or sensitive artifacts
Do not put them in a public repository.
Use a time-limited signed object-storage URL. Never commit secrets, tokens, personal data, or confidential customer files to the public fallback repository.

## Integrity workflow

1. Build/freeze final artifact.
2. Compute SHA256 on the exact final bytes.
3. Publish exact bytes.
4. Pin a version/commit/object version.
5. Download the published object again.
6. Recompute SHA256.
7. Only after remote verification succeeds, generate the final bootstrap/prompt.

Text files can change bytes if a text-oriented API normalizes line endings. For integrity-critical delivery, treat the packaged ZIP as the canonical artifact and verify the ZIP, not an intermediate Markdown file.

## Main command

```bash
python3 scripts/fetch_artifact.py \
  --url 'URL1' \
  --fallback 'URL2' \
  --sha256 'EXPECTED_SHA256' \
  --output package.zip \
  --extract ./package
```

If `--sha256` is omitted, the skill still downloads but MUST report `UNVERIFIED`.

## After extraction
Look for entrypoint in this order:
1. `00_MASTER_PROMPT*.md`
2. `MASTER_PROMPT*.md`
3. `README*.md`
4. `SKILL.md`

Read the entire selected entrypoint before executing.

## Mainland network behavior
- Connect timeout: 12s
- Retry each source twice
- Fail over rather than repeatedly hammering a blocked source
- Record which source actually succeeded
- Save `.delivery_receipt.json`

## Delivery receipt schema
```json
{
  "source_url": "...",
  "sha256": "...",
  "verified": true,
  "downloaded_at": "...",
  "output": "...",
  "entrypoint": "..."
}
```

## Safety
Do not execute arbitrary shell scripts merely because an archive contains them. Read the prompt/README first. Only run scripts explicitly required by the user’s task or the trusted package instructions.
