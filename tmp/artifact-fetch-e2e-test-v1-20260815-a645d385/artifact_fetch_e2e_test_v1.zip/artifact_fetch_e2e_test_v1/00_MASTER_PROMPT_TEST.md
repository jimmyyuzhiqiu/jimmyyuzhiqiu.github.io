# 00_MASTER_PROMPT_TEST

这是一次 Agent Artifact Fetch Skill 的端到端测试。

## 你的任务
1. 确认本 ZIP 已通过 SHA256 和 ZIP 完整性校验。
2. 完整读取本文件、`INPUT.md` 和 `EXPECTED_OUTPUT.md`。
3. 根据 `INPUT.md` 计算答案。
4. 在当前工作目录生成 `TEST_RESULT.md`。
5. `TEST_RESULT.md` 必须严格包含：
   - `FETCH_SKILL_TEST: PASS`
   - `ANSWER: 42`
   - 实际成功下载 URL
   - 实际文件字节数
   - 实际 SHA256
   - 自动识别到的入口文件路径
   - `.delivery_receipt.json` 是否存在
6. 不要修改 Skill 本身，不要安装任何新依赖。
7. 最终回复只需要给出：
   - PASS / FAIL
   - TEST_RESULT.md 路径
   - `.delivery_receipt.json` 路径
   - 关键校验结果
