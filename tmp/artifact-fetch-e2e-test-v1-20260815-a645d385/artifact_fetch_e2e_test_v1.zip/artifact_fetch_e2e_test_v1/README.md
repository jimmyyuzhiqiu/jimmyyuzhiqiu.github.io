# Artifact Fetch E2E Test V1

用于验证已安装的 `Agent Artifact Fetch Skill` 是否能够完成：

公网下载 → fallback → SHA256 → ZIP 校验 → 解压 → 入口识别 → 读取任务 → 生成结果 → 写回执。

优先入口文件：`00_MASTER_PROMPT_TEST.md`
