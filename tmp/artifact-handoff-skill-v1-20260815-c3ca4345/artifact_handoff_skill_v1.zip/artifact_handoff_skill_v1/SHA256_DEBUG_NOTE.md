# 本次 SHA256 不匹配：定位结论

本次本地 `Kadele_EvoMind_V3_SELF_CONTAINED_20260815.md` 的 SHA256 是：

`7c142970ac81660a90800003b6f090503be76436f9e89bdb12bab28b27dfd441`

但本地文件含 **89 个 CRLF**，同时也含 LF，是混合换行文件。其本地 Git blob hash 为：

`237af617d30a4896cbf75752ba748b2345c9702d`

上传到 GitHub 后，远端该文件的 Git blob hash 是：

`af8851c13fef2176f566ac02b55df6325beba63c`

这两个 Git blob hash 不同，说明**远端发布的字节已经与本地计算 SHA256 时的字节不同**。

小龙虾从 jsDelivr / GitHub Pages / GitHub Raw 下载到的三个副本 SHA 一致，则可以排除“某一个 CDN 下载损坏”，问题出在**发布前后字节发生变化，而 bootstrap 仍保存了发布前的旧 SHA256**。

高概率原因是文本经 GitHub 文本 API/JSON 上传后换行/文本表现被规范化；另一个风险是 mutable `@main` URL 的缓存版本。以后通过：

1. 统一 UTF-8 + LF；
2. 优先对 ZIP 二进制包做校验；
3. URL 固定到 commit SHA；
4. 上传后回下载再次计算 SHA256；

即可消除这个问题。
