# Artifact Handoff Skill V1

## Purpose
Use this skill whenever a task produces files that the user will later hand to a remote Linux agent ("小龙虾" / EvoMind / another container).

The delivery is not complete until three surfaces are produced:

1. **ChatGPT file download** — a normal `sandbox:/mnt/data/...` link for the user.
2. **Remote-agent download route** — public temporary URLs that a mainland-China Linux container can try with `curl`/`wget`.
3. **Copy-paste agent prompt** — a concise instruction telling the remote agent exactly what to download, how to verify it, unpack it, and which master prompt to execute.

## Default delivery contract
For every deliverable set, return:

- Primary artifact(s) for direct download in ChatGPT.
- One package ZIP containing the whole execution bundle whenever multiple files are involved.
- SHA256 for the final ZIP and any standalone master prompt.
- Public download routes in this order when available:
  1. jsDelivr **pinned to an immutable Git commit SHA**.
  2. GitHub Raw **pinned to the same immutable commit SHA**.
  3. GitHub Pages latest URL only as a convenience fallback, not as the checksum authority.
- A `bootstrap.sh` that tries routes in order, verifies SHA256, then unpacks.
- A ready-to-send "小龙虾提示词".

For large binary packages (roughly >10 MB) or when mainland reliability matters, prefer a China-region object store (Aliyun OSS / Tencent COS) with a short-lived signed URL when credentials/connectors are available. GitHub/jsDelivr is the fallback.

## Critical checksum rule
**Never publish a SHA256 computed only before upload and assume it is still valid.**

Correct sequence:

1. Finalize the artifact bytes.
2. Compute local SHA256.
3. Upload the exact bytes.
4. Re-download the published object from the primary public URL.
5. Compute SHA256 on the downloaded bytes.
6. If local and public hashes differ, investigate before issuing the link.
7. The checksum placed in `bootstrap.sh` and shown to the user must match the publicly downloadable object.

### Text-file warning
Text uploaded through JSON/API helpers may be rewritten (line endings, trailing newline, Unicode representation). To avoid checksum drift:

- Prefer packaging text into ZIP first and checksum the ZIP; or
- Normalize text to UTF-8 + LF before hashing and upload; or
- Upload exact bytes via a binary/base64 blob API.

Do not checksum a local mixed-CRLF/LF file and then upload it through a text-normalizing API.

## Cache rule
Do not use a mutable `@main` jsDelivr URL as the checksum-critical primary link.

Use:

`https://cdn.jsdelivr.net/gh/<owner>/<repo>@<commit_sha>/<path>`

and raw fallback:

`https://raw.githubusercontent.com/<owner>/<repo>/<commit_sha>/<path>`

This prevents an older CDN cache or a newer branch revision from being served under the same URL.

## Package structure
Recommended bundle:

```
<project>_EXEC_PACKAGE_<date>.zip
├── 00_MASTER_PROMPT_*.md
├── 00_README_*.md
├── source/                 # when permitted/needed
├── prompts/
├── templates/
├── assets/
├── MANIFEST.sha256
└── QA.md
```

The root must contain a master prompt or README that tells an agent what to execute first.

## Public-host hygiene
A GitHub Pages/public-repository route is public and is not truly ephemeral because Git history may persist after deletion. Never publish secrets, access tokens, customer confidential data, children's personal data, medical/financial records, or other sensitive materials this way.

For sensitive material, use a private/signed object-store route instead.

## XiaoLongXia prompt format
Use a compact prompt like:

> 下载并解压下面的执行包，先校验 SHA256，再完整读取根目录 `00_MASTER_PROMPT_*.md`。严格按主提示词执行全部任务，不要只输出概念方案。若首选链接失败，按备用链接顺序重试。完成后把最终产物、QA结果和关键日志发给我。

Then include primary URL, fallback URL(s), SHA256, expected file name, and optional bootstrap command.

## QA before delivery
- [ ] Final files exist and open.
- [ ] ZIP can be listed/unpacked.
- [ ] SHA256 computed after final packaging.
- [ ] Public primary URL uses immutable commit/version.
- [ ] Public object was downloaded back and SHA256 verified.
- [ ] Fallback route points to the same immutable bytes when possible.
- [ ] Bootstrap uses the verified public SHA, not a stale local value.
- [ ] Master prompt path exists inside ZIP.
- [ ] User gets both ChatGPT download link and remote-agent URL/prompt.
