#!/usr/bin/env bash
set -euo pipefail
FILENAME='{{FILENAME}}'
EXPECTED='{{SHA256}}'
URLS=(
  '{{PRIMARY_URL}}'
  '{{FALLBACK_URL}}'
)
for u in "${URLS[@]}"; do
  rm -f "$FILENAME"
  echo "Trying $u" >&2
  if command -v curl >/dev/null 2>&1; then
    curl -fL --connect-timeout 15 --retry 2 "$u" -o "$FILENAME" || continue
  else
    wget --timeout=15 --tries=2 -O "$FILENAME" "$u" || continue
  fi
  ACTUAL=$(sha256sum "$FILENAME" | awk '{print $1}')
  if [ "$ACTUAL" = "$EXPECTED" ]; then
    echo "SHA256 OK: $ACTUAL"
    mkdir -p artifact_exec
    unzip -oq "$FILENAME" -d artifact_exec
    echo "Unpacked to artifact_exec/"
    exit 0
  fi
  echo "SHA mismatch: expected=$EXPECTED actual=$ACTUAL" >&2
done
exit 4
