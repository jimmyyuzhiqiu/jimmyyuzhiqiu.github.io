#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import sys
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

if len(sys.argv) < 2:
    print('usage: make_manifest.py FILE [FILE ...]', file=sys.stderr)
    raise SystemExit(2)

for arg in sys.argv[1:]:
    p = Path(arg)
    print(f'{sha256(p)}  {p.name}')
