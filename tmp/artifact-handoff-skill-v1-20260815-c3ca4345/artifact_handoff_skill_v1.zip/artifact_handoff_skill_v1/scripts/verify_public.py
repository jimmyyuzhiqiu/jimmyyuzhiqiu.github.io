#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import sys
import urllib.request

if len(sys.argv) != 3:
    print('usage: verify_public.py URL EXPECTED_SHA256', file=sys.stderr)
    raise SystemExit(2)
url, expected = sys.argv[1], sys.argv[2].lower()
h = hashlib.sha256()
size = 0
with urllib.request.urlopen(url, timeout=30) as r:
    while True:
        chunk = r.read(1024 * 1024)
        if not chunk:
            break
        size += len(chunk)
        h.update(chunk)
actual = h.hexdigest()
print(f'url={url}')
print(f'bytes={size}')
print(f'sha256={actual}')
if actual != expected:
    print(f'ERROR expected={expected}', file=sys.stderr)
    raise SystemExit(1)
print('OK')
