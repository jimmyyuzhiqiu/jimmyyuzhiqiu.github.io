## 文件下载
- ChatGPT：`[下载完整包](sandbox:/mnt/data/{{FILENAME}})`

## 小龙虾公网下载
- 主链接（commit-pinned jsDelivr）：`{{PRIMARY_URL}}`
- 备用（commit-pinned Raw）：`{{FALLBACK_URL}}`
- SHA256：`{{SHA256}}`

## 一键命令
```bash
curl -fL '{{BOOTSTRAP_URL}}' -o /tmp/artifact-bootstrap.sh && bash /tmp/artifact-bootstrap.sh
```

## 给小龙虾的提示词
见 `templates/xiaolongxia_prompt.md` 模板。
