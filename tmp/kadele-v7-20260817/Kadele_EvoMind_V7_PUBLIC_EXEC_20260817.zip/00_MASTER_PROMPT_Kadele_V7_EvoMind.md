# Kadele × EvoMind《未来月球基地工程》V7 公网执行总提示词

> **最高优先级。** 本文件覆盖 V1–V6 中与本文件冲突的任何结构。目标不是制作“课程介绍材料”，而是完成老师可以直接连续上 4 天的正式课堂执行包。

## 0. 绝对前提

1. 学生在课程开始前已经完整观看月球基地主题影片；**正式课堂不再播放电影，不安排看片环节**。
2. 电影只作为共同背景知识和问题来源。老师可以口头提醒“影片中出现过……”，但不得把课堂时间用于重看片段。
3. 四天课程采用项目制/PBL/工程设计流程：
   **兴趣问题发现 → 自主选题 → 立项 → 组队与分工 → 研究 → 多方案 → 咔得乐快速原型 → 测试/验证 → 失败分析 → 迭代 → 系统解决方案 → 工程答辩。**
4. 咔得乐是非电控实体建构材料。不要虚构传感器、电机、编程、自动控制等不存在的能力。
5. 积木必须贯穿四天，用于思考、表达、模拟、快速建模和验证；不是第四天才开始搭。
6. EvoMind 是 Human-in-the-loop 研究助手，不是答案机。固定机制：学生先想/先写/先搭 → 再问 AI → 学生必须 Accept / Modify / Reject，并写理由和证据。

## 1. 课程总目标

课程名称：《未来月球基地工程》
建议时长：4 天 × 6 小时 = 24 小时 = 1440 分钟。
建议年龄：10–14 岁；正式方案同时给 8–10、10–12、12–14 岁分层。

课程结束时，每个学生团队必须完成：
- 一个清晰的月球工程研究课题；
- Project Charter 立项书；
- 团队角色与分工；
- Research Question Tree；
- 关键事实与证据卡；
- 至少 2–3 个可比较解决方案；
- Prototype V0/V1/V2/V3/Final 的模型演化记录；
- 明确的测试方案、测试记录、失败日志和根因分析；
- 最终解决方案 + 咔得乐实体原型；
- Evidence Board；
- 工程答辩。

## 2. 学生可自主选择的项目市场

不要让所有学生研究同一个题目。制作“Project Marketplace”，学生根据兴趣选题；每组 3–5 人。至少保留以下 12 个推荐方向 + 1 个自由立项：

T01 月球基地选址：光照、水冰、地形、运输、安全如何权衡？
T02 辐射防护：居住和避难空间如何布置以降低风险？
T03 月壤污染控制：气闸、清洁、宇航服和洁污分区如何设计？
T04 月球居住舱：生活、工作、医疗、储存、卫生、安全如何布局？
T05 紧急撤离：太阳风暴预警后，人员如何快速从月球车/户外返回避难区？
T06 月球能源：太阳能区域、输配电概念与关键用能区如何规划？
T07 月球水冰资源：冰矿→开采→运输→处理→储存→使用如何形成闭环？
T08 月球运输：人员、货物、月球车路线如何减少冲突并保持冗余？
T09 机器人作业：哪些危险/重复/极端环境任务应交给机器人？
T10 月壤建筑与防护：危险月壤如何转化为屏蔽/建筑资源？
T11 月球物流与仓储：补给、备件、食物、水、耗材如何储存与流转？
T12 月球系统工程：能源、水、交通、居住、安全、机器人之间的接口如何协调？
T13 自由立项：允许学生提出与“人类长期月球生活/基地运行”有关的新问题；教师用 Scope Gate 判断是否可在 4 天内验证。

每个项目必须制作一张正式 Research Mission Card，包含：
- 影片背景提醒；
- Mission；
- 核心研究问题；
- 3–6 个子问题；
- 必学知识；
- 必须查找的事实/证据；
- 至少两个可搭建的快速模型；
- 至少两个可观察/可比较的测试；
- EvoMind Prompt；
- 与其他项目组的接口；
- 最终答辩必答问题。

## 3. 电影内容如何使用

课堂不播放电影，但设计必须以电影中出现过的关键问题为“共同世界观”。至少覆盖：
- 月球形成、撞击坑与地形；
- 阿波罗登月与“到达≠长期生存”；
- 月球水冰发现；
- 地月约 40 万千米、航行约 3 天的补给困难；
- 宇宙射线、太阳风、高能粒子；
- 微陨石风险；
- 月壤尖锐、带静电、污染机械/人体；
- 月球南极长期光照与太阳能；
- 居住舱、气闸和月壤清洁；
- 太阳风暴预警与紧急返回；
- 月球车与机器人户外作业；
- 月壤屏蔽、月球水泥/3D 打印建筑概念；
- 永久阴影坑与极寒水冰开采；
- 水作为生命支持、氧氢来源、燃料与屏蔽资源；
- 月球门户/轨道前哨站与深空补给。

制作 `FILM_TO_PROJECT_KNOWLEDGE_MAP`，但不要安排“播放第几分钟影片”。每条映射要回答：
**这个电影背景能够触发什么工程问题？学生应该研究什么？最终会改变哪个设计决策？**

## 4. 四天项目制主线

### Day 1｜发现问题、选题、立项与团队形成
目标：从“我觉得有趣”变成“可研究、可验证、四天能完成”的工程项目。

必须完成：
- 课程任务简报；
- 个人兴趣问题池；
- Project Marketplace；
- 选题/自由立项；
- Scope Gate；
- 组队；
- 团队角色：Project Lead、Research Lead、Prototype Lead、Test/Evidence Lead、Presenter（人数不足可兼任）；
- Project Charter；
- Research Question Tree；
- 已知/未知/需要证据；
- Prototype V0：在没有大量研究前，用积木快速表达“我们现在认为解决方案可能是什么”；
- 第一次 EvoMind 风险追问；
- Day1 Gate：问题清晰、范围可控、团队分工明确、至少定义一个可测试指标。

Day1 不能变成“老师讲一天月球知识”。知识必须因学生课题需要而进入。

### Day 2｜研究、证据、多方案与快速原型
目标：用科学事实和工程约束，把模糊想法变成至少 2–3 个可比较方案。

必须完成：
- 研究计划；
- 信息源/证据分级；
- EvoMind 辅助找漏洞而非直接给最终答案；
- Constraint / Criteria；
- 方案 A/B/C；
- Trade-off Matrix；
- 积木 Prototype V1/V2；
- 小规模测试/情境推演；
- 记录观察结果；
- 方案取舍；
- Day2 Gate：至少两套方案可比较，选择理由有证据，并有明确测试计划。

### Day 3｜验证、失败、根因分析与迭代
目标：证明方案是否真的解决问题，而不是“看起来像”。

必须完成：
- Test Plan：测试对象、变量/条件、通过标准、记录方法；
- Challenge Cards；
- 至少一次强制故障/失败情境；
- Prototype V2/V3；
- Failure Log；
- Root Cause：5 Whys / Fishbone 简化版；
- Before/After 对比；
- 与其他项目组做接口审查：例如能源路线挡交通、物流穿生活区、气闸与货运冲突等；
- EvoMind Devil's Advocate；
- Day3 Gate：有可复述的测试证据、有失败、有基于证据的修改，而不是只“继续美化模型”。

### Day 4｜最终解决方案、系统集成、证据板与答辩
目标：把前三天的研究、模型和证据组织成一个可以被质询的工程解决方案。

必须完成：
- Final Design Freeze；
- Final Prototype；
- 最终回归测试；
- Evidence Board；
- 5–7 分钟团队答辩；
- 评委提问；
- 同伴评议；
- 个人反思：最初 V0 和现在有什么不同？哪次失败最有价值？AI 哪条建议被拒绝？为什么？

## 5. 教师逐分钟 SOP——必须真正做到“拿来就上课”

不得再做 19 页、26 页的高密度“课程说明书”来冒充 SOP。

必须输出一个覆盖 **1440 分钟**的教师执行 SOP；推荐 4 天 × 48 个 7–8 分钟微段或等价细度，并可合并为有意义的 10–15 分钟活动块，但每个时间块必须精确标明起止分钟。

每个时间块都必须包含：
1. Day / 时间范围（例如 09:00–09:08）；
2. 对应正式课堂 PPT 页码；
3. 此刻的教学目标；
4. 老师第一句话/关键话术；
5. 老师具体动作；
6. 学生具体动作；
7. 桌面上要有什么材料/卡片；
8. 是否使用咔得乐，具体搭什么/改什么；
9. 是否使用 EvoMind；如使用，给出可复制 Prompt；
10. 这一段必须产出什么纸面/模型/数据；
11. 老师如何快速验收；
12. 常见错误/跑偏；
13. 学生卡住时老师怎么追问；
14. 进度过快的扩展；
15. 进度过慢时的降级方案；
16. 何时拍照/留证；
17. 下一段如何衔接。

要求教师不用自己猜“接下来干什么”，也不用自己再设计问题。

## 6. 正式课堂 PPT——这是最高优先级交付物之一

**禁止再用 20–30 页“课程方案汇报 PPT”代替课堂 PPT。**

必须同时生成两套：

A. 对外/培训用课程方案 PPT：24–32 页。
B. **正式上课用 Classroom PPT：建议 160–220 页，目标约 192 页。**

Classroom PPT 是投影到孩子面前的课堂界面，不是教师说明文档。

至少包含以下页面类型并反复出现：
- 今日任务 / Mission；
- 个人思考；
- Project Marketplace；
- 选题；
- Scope Gate；
- 角色分工；
- Project Charter；
- Research Question Tree；
- 资料研究；
- Build 指令；
- Countdown；
- Test 条件；
- Challenge / Failure；
- 记录证据；
- AI Prompt；
- Accept / Modify / Reject；
- Rebuild；
- Gate Review；
- Evidence Board；
- 答辩规则；
- Reflection。

每页要求：
- 一页一个明确课堂动作；
- 学生 3 秒内看懂“现在要干什么”；
- 不把老师讲稿塞在画面上；
- 大字号、少文字、视觉锚点明确；
- 不能连续 10 页知识讲授；
- 不能每页都是标题 + bullets。

必须先输出 `SLIDE_MANIFEST_P001-P192.md`，每页包含：页码、页面类型、屏幕文案、视觉/图示需求、学生动作、预计停留时间、对应 SOP 时间段、对应打印材料。Manifest 通过 QA 后再批量生成 PPTX。

## 7. 教师 PPT 逐页讲解手册

必须与 Classroom PPT **1:1 对应**，例如 P001–P192 全覆盖。

每页教师条目包含：
- 这一页为什么出现；
- 老师第一句话；
- 30–90 秒讲解建议；
- 老师要问的 1–3 个问题；
- 学生应该做什么；
- 观察什么；
- 学生可能怎么回答；
- 什么答案需要追问；
- 什么时候翻页；
- 如超时怎么处理。

正式 PPT 给学生看；教师逐页讲解手册给老师看。两者不得混为一个文件。

## 8. 学生材料

必须生成可打印学生工程手册（建议 40–60 页），至少包含：
- Mission Passport；
- 兴趣问题池；
- 选题单；
- Project Charter；
- Role Contract；
- Research Question Tree；
- K/W/E（Known/Want-to-know/Evidence）；
- Criteria / Constraints；
- Evidence Card；
- AI Decision Card；
- A/B/C 方案卡；
- Trade-off Matrix；
- Prototype Log；
- Test Plan；
- Test Log；
- Failure Log；
- Root Cause；
- Before/After；
- Final Blueprint；
- BOM；
- Evidence Board 模板；
- Defense Prep；
- Reflection。

## 9. 打印卡

至少 50 张，统一编号：
- PROJECT-xx；
- ROLE-xx；
- SCOPE-xx；
- RESEARCH-xx；
- BUILD-xx；
- TEST-xx；
- CHALLENGE-xx；
- FAILURE-xx；
- CONFLICT-xx；
- AI-DECISION-xx；
- EVIDENCE-xx；
- DEFENSE-xx。

## 10. EvoMind Prompt Library

至少 60 条可复制 Prompt，分类：
- Scope Coach：帮学生缩小题目；
- Question Coach：把兴趣转成可研究问题；
- Evidence Scout：指出需要查什么证据；
- Source Critic：判断资料可靠性；
- Constraint Finder；
- Alternative Generator：只辅助提出备选，不直接替孩子选；
- Risk Reviewer；
- Test Designer；
- Devil's Advocate；
- Root Cause Coach；
- Interface Reviewer；
- Defense Jury。

所有重要 AI 交互必须留下 AI Decision：Accept / Modify / Reject + 理由 + 证据。

## 11. 评价

不要评价“搭得漂亮”。建议：
- 15% 立项质量与问题清晰度；
- 15% 团队合作与角色履职；
- 15% 科学研究与证据质量；
- 20% 工程方案与权衡；
- 20% 测试、失败与迭代；
- 10% AI 素养；
- 5% 工程答辩表达。

## 12. 交付物硬清单

最终 ZIP 至少包含：
1. 课程总方案 PDF + DOCX；
2. 4 天逐分钟教师 SOP PDF + DOCX；
3. Day1–Day4 独立 SOP；
4. Classroom PPT Day1–Day4 + 合并版；
5. 课程方案汇报 PPT；
6. P001–P192 Slide Manifest；
7. 教师 PPT 逐页讲解手册；
8. 学生工程手册；
9. 50+ 打印卡；
10. 12+1 Research Mission Cards；
11. EvoMind 60+ Prompt Library；
12. Film-to-Project Knowledge Map；
13. Science Fact Sheet；
14. BOM / Material List；
15. Rubric；
16. 90–120 秒宣传片 + 脚本 + 字幕；
17. QA Report；
18. Delivery Receipt。

## 13. 硬 QA / FAIL 条件

出现任何一条都判定 FAIL，必须返工：
- 课堂安排重新播放电影；
- 所有学生被强迫研究同一个题目；
- 课程主线不是“立项→分工→研究→方案→验证→迭代→答辩”；
- 积木只在最后一天出现；
- 只有 20–30 页方案型 PPT，没有正式 Classroom PPT；
- 用“方案 PPT + SOP + 卡片”声称等价于正式课堂 PPT；
- SOP 只写“大块 30–60 分钟搭建/讨论”而没有分钟级教师动作；
- Classroom PPT 和 SOP 没有页码/时间 Crosswalk；
- 教师逐页讲解手册未覆盖全部课堂 PPT 页；
- AI 直接替学生完成最终方案；
- 没有失败、测试、迭代证据；
- 虚构咔得乐电控能力；
- 将未来设想当成已验证事实。

## 14. 执行顺序

不要立即生成成品 PPT。

Phase 1：完整读取本执行包。
Phase 2：生成 `COURSE_ARCHITECTURE_V7.md`。
Phase 3：生成 `PROJECT_MARKETPLACE_12_PLUS_1.md`。
Phase 4：生成 `1440_MINUTE_SOP_MANIFEST.md`。
Phase 5：生成 `SLIDE_MANIFEST_P001-P192.md`。
Phase 6：生成 `SOP_PPT_CROSSWALK.md`，证明每个分钟段和每页 PPT 对应。
Phase 7：QA 上述蓝图。若缺失，禁止继续。
Phase 8：生成教师 SOP、学生材料、打印卡、Prompt、正式 Classroom PPT。
Phase 9：生成教师逐页讲解手册。
Phase 10：生成课程方案 PPT 与宣传视频。
Phase 11：渲染 QA、打印 QA、时长 QA、交付 QA。
Phase 12：打包最终 ZIP 并输出 `.delivery_receipt.json`。

## 15. 最终判定标准

老师是否能仅使用“正式课堂 PPT + 教师逐分钟 SOP + 教师逐页讲解手册 + 学生手册 + 卡片 + EvoMind Prompt”连续完成四天课程，而无需自己重新设计课堂？

学生是否能清楚回答：
- 我为什么选这个问题？
- 我在团队里负责什么？
- 我查了什么证据？
- 我们比较过哪些方案？
- 哪次测试失败了？
- 失败为什么发生？
- 我们怎么修改？
- AI 给过什么建议？我们为什么接受/修改/拒绝？
- 为什么最终方案是现在这样？

如果不能，则课程仍未完成。
