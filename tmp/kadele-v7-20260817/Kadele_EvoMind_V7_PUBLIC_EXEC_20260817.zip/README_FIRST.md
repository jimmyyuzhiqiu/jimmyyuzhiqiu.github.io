# EvoMind 公网接收说明

1. 完整解压 ZIP。
2. 首先完整读取 `00_MASTER_PROMPT_Kadele_V7_EvoMind.md`，它是最高优先级入口。
3. `01_SOURCE_电影转录.txt` 仅作为课程背景/事实来源；学生课前已看完影片，正式课堂禁止重新安排看片。
4. 必须先产出课程架构、12+1 项目市场、1440 分钟 SOP Manifest、P001–P192 Slide Manifest、SOP/PPT Crosswalk，并自检通过后才可生成正式资产。
5. 最终必须返回实际生成文件清单与 `.delivery_receipt.json`。
